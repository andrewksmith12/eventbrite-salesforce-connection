
# SALESFORCE CREDENTIALS
SF_SANDBOX_URL = "missioncapitalorg--technofly.my.salesforce.com"
SF_PROD_URL = "missioncapitalorg.my.salesforce.com/"
SF_USERNAME = "teamtechnofly@gmail.com"
SF_PASSWORD = "technofly123!"
SF_PROD_PASSWORD = "clod-ornament-altar-OUTDOORS1"
SF_SANDBOX_SECURITY_TOKEN = "yRpnL38WAghhBlLRAdpzbVpnE"
SF_PROD_SECURITY_TOKEN = "LmePAbLbvLvn4qA7Nn2mepJIO"

#EVENTBRITE CREDENTIALS
EB_API_KEY = "7SJODPMOGANI3QMKGYE5"
EB_TEST_API_KEY = "OULV5QS5WZ4E6QKM3DZN"